package dev.lrxh.api.match;

public interface IMatchService {
    void startMatch(IMatch match);
}
