package dev.lrxh.api.match;

public interface IMatchState {
}
