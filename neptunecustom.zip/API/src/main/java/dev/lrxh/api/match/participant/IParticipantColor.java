package dev.lrxh.api.match.participant;

import org.bukkit.Color;

public interface IParticipantColor {
    String getColor();

    Color getContentColor();
}
