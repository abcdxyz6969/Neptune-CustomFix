package dev.lrxh.api.profile;

public interface IProfileState {
}
