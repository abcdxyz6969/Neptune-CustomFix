package dev.lrxh.api.utils;

public interface ITime {
    String formatTime();

    String formatSecondsMillis();
}
