package com.jonahseguin.drink.annotation;

@Classifier
public @interface Duration {
}
