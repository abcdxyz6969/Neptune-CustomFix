package dev.lrxh.neptune.configs.impl;

import dev.lrxh.neptune.utils.ConfigFile;

public class KitEditorLocationConfig extends ConfigFile {

    public KitEditorLocationConfig() {
        super("kiteditorlocation.yml");
    }
}
