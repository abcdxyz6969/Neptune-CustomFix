package dev.lrxh.neptune.configs.impl.handler;

public enum DataType {
    BOOLEAN,
    STRING,
    STRING_LIST,
    INT
}
