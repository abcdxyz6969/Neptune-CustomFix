package dev.lrxh.neptune.game.arena.impl;

@SuppressWarnings("unused")
public enum EdgeType {
    MIN,
    MAX,
}
