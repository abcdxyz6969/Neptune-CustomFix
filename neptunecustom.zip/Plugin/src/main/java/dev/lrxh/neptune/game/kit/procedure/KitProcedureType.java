package dev.lrxh.neptune.game.kit.procedure;

public enum KitProcedureType {
    RENAME,
    CREATE,
    SET_ICON,
    SET_INV,
    NONE,
    SET_DAMAGE_MULTIPLIER
}
