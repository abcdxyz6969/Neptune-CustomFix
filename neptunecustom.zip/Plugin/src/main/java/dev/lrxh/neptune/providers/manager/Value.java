package dev.lrxh.neptune.providers.manager;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class Value {
    private String name;
    private Object object;
}
