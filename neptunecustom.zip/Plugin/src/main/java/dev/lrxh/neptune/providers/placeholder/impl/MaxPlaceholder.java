package dev.lrxh.neptune.providers.placeholder.impl;

import dev.lrxh.neptune.API;
import dev.lrxh.neptune.game.match.Match;
import dev.lrxh.neptune.game.match.impl.ffa.FfaFightMatch;
import dev.lrxh.neptune.game.match.impl.team.TeamFightMatch;
import dev.lrxh.neptune.profile.impl.Profile;
import dev.lrxh.neptune.providers.placeholder.Placeholder;
import org.bukkit.OfflinePlayer;

public class MaxPlaceholder implements Placeholder {
    @Override
    public boolean match(String string) {
        return string.equals("max");
    }

    @Override
    public String parse(OfflinePlayer player, String string) {
        Profile profile = API.getProfile(player.getUniqueId());
        if (profile == null) return string;
        Match match = profile.getMatch();
        if (match == null) return "";
        if (match instanceof TeamFightMatch tfm) {
            return String.valueOf(tfm.getParticipantTeam(match.getParticipant(player.getUniqueId())).getParticipants().size());
        } else if (match instanceof FfaFightMatch ffm) {
            return String.valueOf(ffm.getParticipants().size());
        } else return "";
    }
}
