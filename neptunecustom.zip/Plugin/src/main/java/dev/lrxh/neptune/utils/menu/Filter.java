package dev.lrxh.neptune.utils.menu;

public enum Filter {
    FILL,
    BORDER,
    NONE
}
