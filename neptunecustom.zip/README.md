why i fork this plugin?

BECAUSE THIS IS MAKE FOR MY DUELS SERVER

donate for me pls:
https://paypal.me/@justmerioeyu

something:

- /neptune arenastats - Open the arena list gui, and info

- /neptune autoforcearenaidlestart <arg, like 15, 15 minutes> - Force the Arena if dont have player, is will force to idle instead of in use, is a bug

- /neptune autoforcearenaidlestop - Stop AutoForceArenaIdle

- /neptune autoforcearenaidlestatus - Status of AutoForceArenaIdle

- /neptune forcearenaidle <arg, arena name> - Fix Map if get Freeze at IN USE

- /neptune startautoreloadsnapshots <arg, like 15, 15 minutes> - Something else...

- /neptune stopautoreloadsnapshots - Just stop auto reload snapshots.

- /neptune reloadsnapshots - Reload snapshots in all arena

- /neptune reloadsnapshotsarena <arg, arena name> - Reload snapshots in target arena

- /neptune setkiteditorlocation - When you in kit editor, you will get teleport to another location, if you dont set, it default in your current location

- /neptune setkiteditorsaveblock - Set a block when you click in, it will save your layout kit

- /neptune setkiteditorresetblock - Set a block when you click in, it will reset your layout kit

- /neptune removekiteditorlocation - Remove your kit editor location if you set

- /neptune stop - Stop the server

if you wanna more things, create a Issues, to request