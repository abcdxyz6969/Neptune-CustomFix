<img width="2000" height="1000" alt="image(6)" src="https://github.com/user-attachments/assets/76ecdb11-ead6-4598-9d0c-4327503df5ec" />

---

## ✨ DOCUMENTATION

- [📃Permissions](./permissions.md)
- [🅿Placeholders](./placeholders.md)
- [💻API](./api.md)

> [!IMPORTANT]
> Join our [Discord server](https://discord.gg/f6rUtpy6y4) for help, updates, and community support.

*MORE INFO COMMING SOON!*
